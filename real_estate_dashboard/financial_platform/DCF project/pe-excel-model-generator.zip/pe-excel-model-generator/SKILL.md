---
name: PE Excel Model Generator
description: Generate professional private equity financial models (DCF, LBO, Merger, DD Tracker, QoE) with preserved formulas using openpyxl. Use when creating or automating financial model generation from database or API data.
version: 1.0.0
dependencies:
  - python>=3.8
  - openpyxl>=3.1.0
  - sqlalchemy>=2.0.0
  - fastapi>=0.100.0
  - pydantic>=2.0.0
---

# PE Excel Model Generator Skill

## Overview

This skill enables Claude to generate enterprise-grade private equity financial models with **all formulas preserved**. It's specifically designed for PE portfolio management platforms where models must be generated programmatically from database data while maintaining Excel formula integrity.

**Core Capability:** Transform database records into fully functional Excel models in under 10 seconds per model.

## When to Use This Skill

Claude should invoke this skill when:
- User asks to "generate an Excel model" or "create a DCF/LBO/Merger model"
- User wants to automate financial model creation
- User needs to preserve formulas in Excel outputs (not just values)
- User is working with portfolio company data that needs to flow into models
- User mentions "openpyxl", "Excel automation", or "formula preservation"
- User asks about integrating financial models with a database
- User needs to generate models for multiple companies (batch generation)

**Do NOT use for:**
- Simple data exports (use pandas `.to_excel()` instead)
- Models without formulas (use simple CSV/XLSX writers)
- One-time manual model creation (just use Excel directly)

## Supported Models

1. **DCF Model** - 13 sheets, 600+ formulas, NPV/IRR calculations
2. **LBO Model** - 12 sheets, 500+ formulas, debt waterfall, returns analysis
3. **Merger Model** - 10 sheets, 400+ formulas, accretion/dilution analysis
4. **DD Tracker** - 8 sheets, 140-item due diligence checklist
5. **QoE Analysis** - 6 sheets, 315 formulas, EBITDA adjustments

## Critical Principles

### 1. NEVER Overwrite Formulas

This is the #1 rule of this skill. Excel models have two types of cells:

**Input Cells** (Blue/Yellow fill in templates):
- These contain raw data values
- Safe to overwrite with database values
- Example: Company name, revenue, WACC

**Formula Cells** (No fill color):
- These contain calculations
- NEVER overwrite these
- Example: `=NPV(B5, C10:F10)`, `=C8*(1+C9)`

```python
# ✅ CORRECT - Only write to input cells
ws['C8'].value = 1000000  # Input: Base year revenue
# Cell C9 formula remains intact: =C8*(1+C10)

# ❌ WRONG - This destroys the formula
ws['C9'].value = 1100000  # This overwrites formula with static value!
```

### 2. Use Cell References, Not Values

When you need to reference data between sheets, use Excel cell references:

```python
# ✅ CORRECT
ws['Summary!B5'].value = '=DCF!C25'  # Links to DCF sheet

# ❌ WRONG
ws['Summary!B5'].value = 15000000  # Static value, no link
```

### 3. Preserve Template Structure

The comprehensive Excel models have a specific structure:
- Input cells are marked with colored fill
- Headers have specific styling
- Formulas reference named ranges
- Multiple sheets are interconnected

**Never** modify the template structure. Only populate input cells.

## Database Integration Pattern

### Standard Architecture

```
PostgreSQL Database
    ↓
SQLAlchemy ORM (Models: PortfolioCompany, FinancialMetric, Valuation)
    ↓
ModelGenerator Classes (DCFModelGenerator, LBOModelGenerator, etc.)
    ↓
Load Excel Template (.xlsx file with all formulas)
    ↓
Map database fields → Excel input cells
    ↓
Save generated model (all formulas intact)
```

### Key Database Tables

```python
# Core tables for model generation:
portfolio_companies  # Company info, investment date, sector
financial_metrics    # Time-series P&L, balance sheet, cash flow
valuations          # DCF inputs (WACC, terminal growth, multiples)
company_kpis        # Operational metrics (ARR, churn, etc.)
transactions        # Deal terms, entry/exit multiples
```

## Code Examples

### Example 1: Generate a Single DCF Model

```python
from excel_model_generator import DCFModelGenerator
from sqlalchemy import create_engine
from sqlalchemy.orm import sessionmaker
import os

# Setup database connection
DATABASE_URL = os.getenv('DATABASE_URL')
engine = create_engine(DATABASE_URL)
Session = sessionmaker(bind=engine)
db = Session()

# Generate DCF model for a specific company
company_id = '123e4567-e89b-12d3-a456-426614174000'
generator = DCFModelGenerator(db, company_id)

# Generate and save
output_path = '/home/claude/outputs/Acme_Corp_DCF.xlsx'
generator.generate(output_path)

print(f"✓ DCF model generated: {output_path}")
print(f"✓ All 600+ formulas preserved")
print(f"✓ Company data populated from database")
```

### Example 2: Batch Generate Models for All Portfolio Companies

```python
from excel_model_generator import BatchModelGenerator

# Get all active companies
companies = db.query(PortfolioCompany).filter_by(status='Active').all()

# Generate models
batch_gen = BatchModelGenerator(db)

for company in companies:
    results = batch_gen.generate_all_models(
        company_id=company.id,
        output_dir=f'/outputs/{company.slug}'
    )
    
    print(f"Generated for {company.name}:")
    print(f"  DCF: {results['DCF']}")
    print(f"  LBO: {results['LBO']}")
```

### Example 3: API Endpoint for Model Generation

```python
from fastapi import FastAPI, HTTPException
from pydantic import BaseModel
import uuid

app = FastAPI()

class ModelRequest(BaseModel):
    company_id: str
    model_type: str  # 'dcf', 'lbo', 'merger', 'dd', 'qoe'

@app.post("/api/generate-model")
async def generate_model(request: ModelRequest):
    """Generate a financial model on demand"""
    
    # Validate UUID
    try:
        company_uuid = uuid.UUID(request.company_id)
    except ValueError:
        raise HTTPException(400, "Invalid company_id format")
    
    # Select generator
    generators = {
        'dcf': DCFModelGenerator,
        'lbo': LBOModelGenerator,
        'merger': MergerModelGenerator,
        'dd': DDTrackerGenerator,
        'qoe': QoEAnalysisGenerator
    }
    
    generator_class = generators.get(request.model_type.lower())
    if not generator_class:
        raise HTTPException(400, f"Unknown model_type: {request.model_type}")
    
    # Generate
    try:
        generator = generator_class(db, str(company_uuid))
        output_path = f'/generated/{company_uuid}_{request.model_type}.xlsx'
        generator.generate(output_path)
        
        return {
            "status": "success",
            "file_path": output_path,
            "model_type": request.model_type,
            "company_id": request.company_id
        }
    except Exception as e:
        raise HTTPException(500, f"Generation failed: {str(e)}")
```

### Example 4: Cell Mapping Pattern

```python
def _populate_company_info(self):
    """Map database fields to Excel cells"""
    sheet = self.wb['Cover']
    
    # Company basics
    sheet['B2'].value = self.company.company_name
    sheet['B3'].value = self.company.sector
    sheet['B4'].value = self.company.investment_date
    
    # Apply styling to input cells
    apply_input_style(sheet['B2'])
    apply_input_style(sheet['B3'])
    apply_input_style(sheet['B4'])
    
    # Financial metrics (latest year)
    if self.financials:
        latest = self.financials[-1]
        
        sheet['C8'].value = float(latest.revenue)
        sheet['C9'].value = float(latest.ebitda)
        sheet['C10'].value = float(latest.ebitda_margin)
        
        # Apply formatting
        apply_number_format(sheet['C8'], 'currency')
        apply_number_format(sheet['C9'], 'currency')
        apply_number_format(sheet['C10'], 'percent')
    
    # Note: Formula cells (like C11 = C9/C8) are NEVER touched
```

### Example 5: Formula Preservation Verification

```python
def verify_formula_preservation(filepath: str) -> dict:
    """Verify that formulas were preserved after generation"""
    from openpyxl import load_workbook
    
    wb = load_workbook(filepath)
    results = {
        'total_cells_checked': 0,
        'formula_cells': 0,
        'value_cells': 0,
        'errors': []
    }
    
    for sheet_name in wb.sheetnames:
        sheet = wb[sheet_name]
        
        for row in sheet.iter_rows():
            for cell in row:
                if cell.value is not None:
                    results['total_cells_checked'] += 1
                    
                    # Check if it's a formula
                    if isinstance(cell.value, str) and cell.value.startswith('='):
                        results['formula_cells'] += 1
                    else:
                        results['value_cells'] += 1
                    
                    # Check for common errors
                    if cell.value == '#REF!':
                        results['errors'].append(f"{sheet_name}!{cell.coordinate}")
    
    return results
```

## Styling Functions

Claude should use these helper functions to maintain consistent formatting:

```python
def apply_header_style(cell):
    """Apply header styling (dark blue background, white text, bold)"""
    from openpyxl.styles import Font, PatternFill, Alignment, Border, Side
    
    cell.font = Font(name='Calibri', size=11, bold=True, color='FFFFFF')
    cell.fill = PatternFill(start_color='366092', end_color='366092', fill_type='solid')
    cell.alignment = Alignment(horizontal='center', vertical='center')
    cell.border = Border(
        left=Side(style='thin'),
        right=Side(style='thin'),
        top=Side(style='thin'),
        bottom=Side(style='thin')
    )

def apply_input_style(cell):
    """Apply input cell styling (yellow background for user-editable cells)"""
    cell.font = Font(name='Calibri', size=10, color='000000')
    cell.fill = PatternFill(start_color='FFFFCC', end_color='FFFFCC', fill_type='solid')
    cell.alignment = Alignment(horizontal='right')

def apply_number_format(cell, format_type='currency'):
    """Apply number formatting"""
    formats = {
        'currency': '$#,##0',
        'currency_decimal': '$#,##0.00',
        'percent': '0.0%',
        'percent_decimal': '0.00%',
        'number': '#,##0',
        'decimal': '#,##0.00',
        'multiple': '0.0x'
    }
    cell.number_format = formats.get(format_type, formats['currency'])
```

## Database → Excel Mapping Reference

### DCF Model Mappings

| Database Field | Excel Cell | Sheet | Format |
|---------------|------------|-------|--------|
| company.company_name | B2 | Cover | Text |
| company.investment_date | B4 | Cover | Date |
| latest.revenue | C8 | DCF | Currency |
| latest.ebitda | C15 | DCF | Currency |
| valuation.wacc | C5 | WACC | Percent |
| valuation.terminal_growth | C16 | DCF | Percent |
| valuation.unlevered_beta | C8 | WACC | Decimal |

### LBO Model Mappings

| Database Field | Excel Cell | Sheet | Format |
|---------------|------------|-------|--------|
| company.entry_multiple | C9 | Transaction | Multiple (0.0x) |
| company.equity_invested | C10 | Sources & Uses | Currency |
| company.debt_raised | C15 | Sources & Uses | Currency |
| valuation.exit_multiple | C12 | Transaction | Multiple |
| latest.revenue | C8 | Operating Model | Currency |

### Merger Model Mappings

| Database Field | Excel Cell | Sheet | Format |
|---------------|------------|-------|--------|
| acquirer.shares_outstanding | C10 | Assumptions | Number |
| target.purchase_price | C15 | PPA | Currency |
| synergies.cost_synergies | C20 | Synergies | Currency |
| synergies.revenue_synergies | C25 | Synergies | Currency |

## Common Pitfalls and Solutions

### Pitfall 1: Overwriting Formulas

**Problem:**
```python
# This destroys the formula
ws['D10'].value = 1500000
```

**Solution:**
```python
# Only write to input cells, formulas auto-calculate
ws['C10'].value = 1000000  # Input cell
# D10 formula =C10*1.5 calculates automatically
```

### Pitfall 2: Incorrect Cell References

**Problem:**
```python
# Relative reference breaks when cells move
ws['B5'].value = '=C10'
```

**Solution:**
```python
# Use absolute references for stability
ws['B5'].value = '=$C$10'
```

### Pitfall 3: Missing Data Validation

**Problem:**
```python
# No validation, bad data can crash model
ws['C10'].value = user_input
```

**Solution:**
```python
# Validate before writing
if user_input and float(user_input) > 0:
    ws['C10'].value = float(user_input)
else:
    raise ValueError("Revenue must be positive")
```

### Pitfall 4: Template Not Found

**Problem:**
```python
template = '/wrong/path/DCF_Model.xlsx'
wb = load_workbook(template)  # FileNotFoundError
```

**Solution:**
```python
import os
template = '/mnt/user-data/uploads/DCF_Model_Comprehensive.xlsx'

if not os.path.exists(template):
    raise FileNotFoundError(f"Template not found: {template}")

wb = load_workbook(template)
```

## Performance Optimization

### 1. Cache Templates
```python
# Load template once, reuse for multiple companies
template_cache = {}

def get_template(model_type):
    if model_type not in template_cache:
        path = f'/templates/{model_type}_Model_Comprehensive.xlsx'
        template_cache[model_type] = load_workbook(path)
    return template_cache[model_type].copy()  # Return a copy
```

### 2. Batch Database Queries
```python
# ❌ Bad - N+1 query problem
for company_id in company_ids:
    company = db.query(PortfolioCompany).get(company_id)
    # Generate model...

# ✅ Good - Single query with joins
companies = db.query(PortfolioCompany)\
    .options(joinedload(PortfolioCompany.financials))\
    .options(joinedload(PortfolioCompany.valuation))\
    .filter(PortfolioCompany.id.in_(company_ids))\
    .all()
```

### 3. Use Background Tasks for Large Batches
```python
from fastapi import BackgroundTasks

@app.post("/api/batch-generate")
async def batch_generate(company_ids: list[str], background_tasks: BackgroundTasks):
    """Generate models in background for better UX"""
    
    background_tasks.add_task(generate_all_models, company_ids)
    
    return {
        "status": "queued",
        "message": f"Generating models for {len(company_ids)} companies"
    }
```

## Testing and Validation

### Test Checklist

After generating a model, verify:

1. **Formula Preservation** - Open in Excel, check that calculations work
2. **Data Accuracy** - Compare input cells vs database values
3. **Formatting** - Check currency, percent, date formats
4. **Links** - Verify sheet references work correctly
5. **No Errors** - Search for #REF!, #VALUE!, #DIV/0!

### Automated Testing

```python
def test_dcf_generation():
    """Test DCF model generation"""
    generator = DCFModelGenerator(db, test_company_id)
    output_path = '/tmp/test_dcf.xlsx'
    
    generator.generate(output_path)
    
    # Verify file exists
    assert os.path.exists(output_path)
    
    # Verify formulas preserved
    wb = load_workbook(output_path)
    assert '=NPV' in str(wb['DCF']['C20'].value)
    
    # Verify data populated
    assert wb['Cover']['B2'].value == 'Test Company'
    
    print("✓ DCF generation test passed")
```

## Integration with Portfolio Dashboard

This skill is designed to integrate with your Portfolio Dashboard project:

1. **API Layer**: FastAPI endpoints expose model generation
2. **Database Layer**: SQLAlchemy models map to database tables
3. **Template Storage**: Excel templates stored in `/mnt/user-data/uploads/`
4. **Output Storage**: Generated models saved to `/mnt/user-data/outputs/`
5. **Frontend**: React dashboard calls API to trigger generation

## Best Practices Summary

1. ✅ **NEVER overwrite formula cells** - Only populate input cells
2. ✅ **Use absolute references** - `=$C$10` instead of `=C10`
3. ✅ **Validate all inputs** - Check data types and ranges
4. ✅ **Apply consistent styling** - Use helper functions
5. ✅ **Test formula preservation** - Verify models open correctly in Excel
6. ✅ **Handle errors gracefully** - Catch exceptions, log errors
7. ✅ **Cache templates** - Don't reload for every model
8. ✅ **Batch database queries** - Avoid N+1 problems
9. ✅ **Document mappings** - Maintain field → cell reference tables
10. ✅ **Version control templates** - Track changes to Excel files

## Resources

For more information, see:
- **REFERENCE.md** - Complete database → Excel mapping tables for all 5 models
- **excel_model_generator.py** - Full implementation code (790 lines)
- **example_usage.py** - 10 working examples
- **MODEL_GENERATION_GUIDE.md** - Technical documentation
- Project files: DCF_Model_Comprehensive.xlsx, LBO_Model_Comprehensive.xlsx, etc.

## Version History

- **1.0.0** (Current) - Initial release with DCF, LBO, Merger, DD, QoE support
