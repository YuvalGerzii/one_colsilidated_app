# Quick Start Guide - PE Excel Model Generator Skill

## 5-Minute Setup

### Step 1: Review the Skill (1 min)

You should have these files in your folder:
- ✅ SKILL.md (main skill definition)
- ✅ REFERENCE.md (mappings reference)
- ✅ README.md (documentation)
- ✅ requirements.txt (dependencies)
- ✅ excel_model_generator.py (core code)
- ✅ example_usage.py (examples)

### Step 2: Test Locally (Optional, 2 min)

Before uploading to Claude, test the code works:

```bash
# Install dependencies
pip install openpyxl sqlalchemy fastapi --break-system-packages

# Run a quick test
python example_usage.py 6  # Runs validation example
```

### Step 3: Create ZIP File (1 min)

**Important:** The ZIP must have the skill folder as the root.

```bash
cd /home/claude
zip -r pe-excel-model-generator.zip pe-excel-model-generator/

# Verify structure (should show pe-excel-model-generator/ as root)
unzip -l pe-excel-model-generator.zip | head -20
```

**Correct structure:**
```
pe-excel-model-generator.zip
└── pe-excel-model-generator/
    ├── SKILL.md
    ├── REFERENCE.md
    ├── README.md
    ├── requirements.txt
    ├── excel_model_generator.py
    └── example_usage.py
```

**Wrong structure (don't do this):**
```
pe-excel-model-generator.zip
├── SKILL.md
├── REFERENCE.md
└── ...
```

### Step 4: Upload to Claude (1 min)

1. Go to https://claude.ai
2. Click your profile → Settings
3. Navigate to: **Capabilities** section
4. Scroll to **Skills**
5. Click **Upload Skill**
6. Select `pe-excel-model-generator.zip`
7. Wait for upload (should take 5-10 seconds)
8. **Enable** the skill (toggle switch)

### Step 5: Test in Claude (1 min)

Start a new conversation and try:

```
Create a DCF model for a company with these details:
- Company: Acme Corp
- Revenue: $50M
- EBITDA: $12M
- WACC: 9.5%
```

Claude should:
1. Recognize this is a model generation task
2. Invoke the PE Excel Model Generator skill
3. Provide code using the skill's patterns
4. Explain how to run it

---

## Troubleshooting

### Issue: Claude doesn't use the skill

**Fix:** Make sure:
1. The skill is **enabled** in Settings → Capabilities
2. Your prompt mentions "model", "Excel", "DCF", "LBO", or similar keywords
3. Try being more explicit: "Use the Excel model generator to..."

### Issue: ZIP upload fails

**Error:** "Invalid skill format"

**Fix:** 
1. Verify ZIP structure (folder should be at root)
2. Ensure SKILL.md has valid YAML frontmatter
3. Check file permissions

### Issue: Skill loads but doesn't work

**Fix:**
1. Check the SKILL.md `description` field - this is what Claude uses to decide when to invoke
2. Make it more specific or add more trigger keywords
3. Re-upload after editing

---

## Next Steps

Once the skill is working:

1. **Test with your database**
   - Update DATABASE_URL in code
   - Test with real company IDs

2. **Customize for your needs**
   - Modify cell mappings in code
   - Add custom model types
   - Adjust styling functions

3. **Create more skills**
   - PE Financial Modeling Standards skill
   - Database Schema skill
   - PDF Extraction skill

4. **Share with team**
   - Export the ZIP
   - Team members can import
   - Maintains consistency

---

## Pro Tips

### Tip 1: Iterate on the Description

The `description` field in SKILL.md is critical. If Claude isn't using your skill, try:

```yaml
# Too vague
description: Generate Excel models

# Better
description: Generate professional PE financial models (DCF, LBO, Merger) with preserved formulas using openpyxl

# Best
description: Generate professional private equity financial models (DCF, LBO, Merger, DD Tracker, QoE) with preserved formulas using openpyxl. Use when creating or automating financial model generation from database or API data.
```

### Tip 2: Add Examples to SKILL.md

The more examples you include, the better Claude understands usage patterns.

### Tip 3: Version Your Skills

When you make significant changes:
1. Update the `version` field in SKILL.md
2. Save the old ZIP as `pe-excel-model-generator-v1.0.0.zip`
3. Upload new version

### Tip 4: Test with Edge Cases

Try these to ensure robustness:
- Company with missing financial data
- Invalid company ID
- Empty database
- Very large portfolio (100+ companies)

---

## Verification Checklist

Before uploading, verify:

- [ ] SKILL.md has valid YAML frontmatter
- [ ] `name` field is descriptive (≤64 chars)
- [ ] `description` field explains when to use (≤200 chars)
- [ ] All Python files have no syntax errors
- [ ] ZIP structure is correct (folder at root)
- [ ] requirements.txt lists all dependencies
- [ ] README.md explains usage clearly

---

## Support

If you encounter issues:

1. **Check Claude's thinking:** Look for skill invocation in thinking blocks
2. **Review logs:** Check for Python errors in terminal
3. **Test locally:** Run example_usage.py to isolate issues
4. **Simplify:** Start with the simplest example (example 1)
5. **Ask Claude:** "Why didn't you use the Excel model generator skill?"

---

## Success Metrics

You'll know the skill is working well when:

✅ Claude automatically invokes it for model generation tasks
✅ Generated models open correctly in Excel
✅ All formulas are preserved (no #REF! errors)
✅ Database queries return expected data
✅ Generation time is <15 seconds per model
✅ Team members can use it consistently

---

**You're ready!** Create the ZIP and upload to Claude.

Total setup time: **5 minutes**
Value delivered: **Automated model generation for 100+ companies**
