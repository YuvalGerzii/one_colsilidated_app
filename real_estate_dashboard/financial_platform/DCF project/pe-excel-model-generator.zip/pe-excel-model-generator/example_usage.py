"""
Excel Model Generator - Usage Examples
Demonstrates all major use cases for the PE Excel Model Generator
"""

import os
from excel_model_generator import (
    DCFModelGenerator,
    LBOModelGenerator,
    MergerModelGenerator,
    BatchModelGenerator
)
from sqlalchemy import create_engine
from sqlalchemy.orm import sessionmaker
import uuid


# ============================================================================
# SETUP
# ============================================================================

def setup_database():
    """Initialize database connection"""
    DATABASE_URL = os.getenv('DATABASE_URL', 'postgresql://portfolio_user:password@localhost/portfolio_db')
    engine = create_engine(DATABASE_URL)
    Session = sessionmaker(bind=engine)
    return Session()


# ============================================================================
# EXAMPLE 1: Generate Single DCF Model
# ============================================================================

def example_1_single_dcf():
    """
    Most basic use case: Generate one DCF model for a company
    """
    print("\n=== Example 1: Single DCF Model ===")
    
    db = setup_database()
    
    # Use a real company UUID from your database
    company_id = '123e4567-e89b-12d3-a456-426614174000'
    
    # Create generator
    generator = DCFModelGenerator(db, company_id)
    
    # Generate model
    output_path = '/home/claude/outputs/Acme_Corp_DCF.xlsx'
    generator.generate(output_path)
    
    print(f"✓ DCF model generated: {output_path}")
    print(f"✓ All formulas preserved")
    print(f"✓ Company data populated from database")
    
    db.close()


# ============================================================================
# EXAMPLE 2: Generate Single LBO Model
# ============================================================================

def example_2_single_lbo():
    """
    Generate an LBO model with returns analysis
    """
    print("\n=== Example 2: Single LBO Model ===")
    
    db = setup_database()
    company_id = '123e4567-e89b-12d3-a456-426614174001'
    
    generator = LBOModelGenerator(db, company_id)
    output_path = '/home/claude/outputs/Target_Co_LBO.xlsx'
    generator.generate(output_path)
    
    print(f"✓ LBO model generated: {output_path}")
    print(f"✓ IRR and MOIC calculations intact")
    print(f"✓ Debt schedule with waterfall")
    
    db.close()


# ============================================================================
# EXAMPLE 3: Batch Generate Multiple Models for One Company
# ============================================================================

def example_3_batch_single_company():
    """
    Generate all 5 models for a single portfolio company
    """
    print("\n=== Example 3: Batch Generate All Models ===")
    
    db = setup_database()
    company_id = '123e4567-e89b-12d3-a456-426614174002'
    
    # Create batch generator
    batch = BatchModelGenerator(db)
    
    # Generate all models
    results = batch.generate_all_models(
        company_id=company_id,
        output_dir='/home/claude/outputs/portfolio_company_1'
    )
    
    print("\nGeneration Results:")
    for model_type, path in results.items():
        if path:
            print(f"  ✓ {model_type}: {path}")
        else:
            print(f"  ✗ {model_type}: Failed")
    
    db.close()


# ============================================================================
# EXAMPLE 4: Batch Generate for Entire Portfolio
# ============================================================================

def example_4_batch_entire_portfolio():
    """
    Generate DCF models for all active portfolio companies
    """
    print("\n=== Example 4: Entire Portfolio Batch Generation ===")
    
    from excel_model_generator import PortfolioCompany
    
    db = setup_database()
    
    # Get all active companies
    companies = db.query(PortfolioCompany)\
        .filter(PortfolioCompany.company_status == 'Active')\
        .all()
    
    print(f"Found {len(companies)} active companies")
    
    batch = BatchModelGenerator(db)
    
    for company in companies:
        print(f"\nGenerating models for: {company.company_name}")
        
        try:
            results = batch.generate_all_models(
                company_id=str(company.company_id),
                output_dir=f'/home/claude/outputs/{company.company_name.replace(" ", "_")}'
            )
            
            print(f"  ✓ Generated {len([r for r in results.values() if r])} models")
            
        except Exception as e:
            print(f"  ✗ Failed: {e}")
    
    db.close()


# ============================================================================
# EXAMPLE 5: Custom Template Path
# ============================================================================

def example_5_custom_template():
    """
    Use a custom template location (useful for versioned templates)
    """
    print("\n=== Example 5: Custom Template Path ===")
    
    db = setup_database()
    company_id = '123e4567-e89b-12d3-a456-426614174003'
    
    # Use a specific template version
    custom_template = '/home/claude/templates/DCF_Model_v2.xlsx'
    
    generator = DCFModelGenerator(
        db_session=db,
        company_id=company_id,
        template_path=custom_template
    )
    
    output_path = '/home/claude/outputs/Custom_Template_DCF.xlsx'
    generator.generate(output_path)
    
    print(f"✓ Model generated using custom template")
    
    db.close()


# ============================================================================
# EXAMPLE 6: Validate Generated Model
# ============================================================================

def example_6_validate_model():
    """
    Verify that formulas were preserved correctly
    """
    print("\n=== Example 6: Model Validation ===")
    
    from openpyxl import load_workbook
    
    filepath = '/home/claude/outputs/Acme_Corp_DCF.xlsx'
    
    wb = load_workbook(filepath)
    
    validation_results = {
        'total_cells': 0,
        'formula_cells': 0,
        'value_cells': 0,
        'errors': []
    }
    
    for sheet_name in wb.sheetnames:
        sheet = wb[sheet_name]
        
        for row in sheet.iter_rows():
            for cell in row:
                if cell.value is not None:
                    validation_results['total_cells'] += 1
                    
                    # Check if it's a formula
                    if isinstance(cell.value, str) and cell.value.startswith('='):
                        validation_results['formula_cells'] += 1
                    else:
                        validation_results['value_cells'] += 1
                    
                    # Check for errors
                    if isinstance(cell.value, str) and cell.value.startswith('#'):
                        validation_results['errors'].append(f"{sheet_name}!{cell.coordinate}: {cell.value}")
    
    print(f"\nValidation Results:")
    print(f"  Total cells: {validation_results['total_cells']}")
    print(f"  Formula cells: {validation_results['formula_cells']}")
    print(f"  Value cells: {validation_results['value_cells']}")
    print(f"  Errors: {len(validation_results['errors'])}")
    
    if validation_results['errors']:
        print(f"\n  Error cells:")
        for error in validation_results['errors'][:5]:  # Show first 5
            print(f"    - {error}")
    else:
        print(f"  ✓ No formula errors detected")


# ============================================================================
# EXAMPLE 7: Generate with Missing Data Handling
# ============================================================================

def example_7_missing_data_handling():
    """
    Handle cases where company has incomplete data
    """
    print("\n=== Example 7: Missing Data Handling ===")
    
    db = setup_database()
    company_id = '123e4567-e89b-12d3-a456-426614174004'
    
    try:
        generator = DCFModelGenerator(db, company_id)
        output_path = '/home/claude/outputs/Incomplete_Data_DCF.xlsx'
        generator.generate(output_path)
        
        print(f"✓ Model generated despite missing data")
        print(f"✓ Empty cells will show as blank (formulas still work)")
        
    except ValueError as e:
        print(f"✗ Cannot generate model: {e}")
        print(f"  Required fields missing")
    
    db.close()


# ============================================================================
# EXAMPLE 8: Performance Benchmarking
# ============================================================================

def example_8_performance_benchmark():
    """
    Measure generation time for different model types
    """
    print("\n=== Example 8: Performance Benchmark ===")
    
    import time
    
    db = setup_database()
    company_id = '123e4567-e89b-12d3-a456-426614174005'
    
    models = [
        ('DCF', DCFModelGenerator),
        ('LBO', LBOModelGenerator),
    ]
    
    for model_name, generator_class in models:
        start_time = time.time()
        
        try:
            generator = generator_class(db, company_id)
            output_path = f'/tmp/benchmark_{model_name}.xlsx'
            generator.generate(output_path)
            
            elapsed = time.time() - start_time
            file_size = os.path.getsize(output_path) / (1024 * 1024)  # MB
            
            print(f"\n{model_name} Model:")
            print(f"  Time: {elapsed:.2f} seconds")
            print(f"  Size: {file_size:.2f} MB")
            
            # Clean up
            os.remove(output_path)
            
        except Exception as e:
            print(f"\n{model_name} Model:")
            print(f"  ✗ Failed: {e}")
    
    db.close()


# ============================================================================
# EXAMPLE 9: Merger Model (Two Companies)
# ============================================================================

def example_9_merger_model():
    """
    Generate a merger model analyzing acquirer + target
    """
    print("\n=== Example 9: Merger Model ===")
    
    db = setup_database()
    
    acquirer_id = '123e4567-e89b-12d3-a456-426614174006'
    target_id = '123e4567-e89b-12d3-a456-426614174007'
    
    generator = MergerModelGenerator(
        db_session=db,
        acquirer_id=acquirer_id,
        target_id=target_id
    )
    
    output_path = '/home/claude/outputs/Merger_Analysis.xlsx'
    generator.generate(output_path)
    
    print(f"✓ Merger model generated: {output_path}")
    print(f"✓ Accretion/dilution analysis included")
    print(f"✓ Pro forma statements created")
    
    db.close()


# ============================================================================
# EXAMPLE 10: API Integration
# ============================================================================

def example_10_api_integration():
    """
    Example of how to integrate with FastAPI
    """
    print("\n=== Example 10: API Integration ===")
    
    # This would typically be in your api_model_generator.py file
    from fastapi import FastAPI, HTTPException, BackgroundTasks
    from pydantic import BaseModel
    
    app = FastAPI()
    
    class ModelRequest(BaseModel):
        company_id: str
        model_type: str
    
    @app.post("/api/generate-model")
    async def generate_model(request: ModelRequest, background_tasks: BackgroundTasks):
        """Generate a model via API"""
        
        # Validate inputs
        try:
            company_uuid = uuid.UUID(request.company_id)
        except ValueError:
            raise HTTPException(status_code=400, detail="Invalid company_id")
        
        # Map model type to generator
        generators = {
            'dcf': DCFModelGenerator,
            'lbo': LBOModelGenerator,
            'merger': MergerModelGenerator,
        }
        
        generator_class = generators.get(request.model_type.lower())
        if not generator_class:
            raise HTTPException(status_code=400, detail=f"Unknown model_type: {request.model_type}")
        
        # Generate in background
        def generate_task():
            db = setup_database()
            try:
                generator = generator_class(db, str(company_uuid))
                output_path = f'/generated/{company_uuid}_{request.model_type}.xlsx'
                generator.generate(output_path)
            finally:
                db.close()
        
        background_tasks.add_task(generate_task)
        
        return {
            "status": "queued",
            "company_id": request.company_id,
            "model_type": request.model_type,
            "message": "Model generation started"
        }
    
    print("FastAPI integration example shown above")
    print("Start server with: uvicorn api_model_generator:app --reload")


# ============================================================================
# MAIN
# ============================================================================

def main():
    """Run all examples"""
    
    print("\n" + "="*60)
    print("PE Excel Model Generator - Usage Examples")
    print("="*60)
    
    examples = [
        ("Single DCF Model", example_1_single_dcf),
        ("Single LBO Model", example_2_single_lbo),
        ("Batch Single Company", example_3_batch_single_company),
        ("Batch Entire Portfolio", example_4_batch_entire_portfolio),
        ("Custom Template", example_5_custom_template),
        ("Validate Model", example_6_validate_model),
        ("Missing Data Handling", example_7_missing_data_handling),
        ("Performance Benchmark", example_8_performance_benchmark),
        ("Merger Model", example_9_merger_model),
        ("API Integration", example_10_api_integration),
    ]
    
    print("\nAvailable Examples:")
    for i, (name, _) in enumerate(examples, 1):
        print(f"  {i}. {name}")
    
    print("\nTo run a specific example:")
    print("  python example_usage.py <number>")
    print("\nTo run all examples:")
    print("  python example_usage.py")


if __name__ == '__main__':
    import sys
    
    if len(sys.argv) > 1:
        # Run specific example
        example_num = int(sys.argv[1])
        examples = [
            example_1_single_dcf,
            example_2_single_lbo,
            example_3_batch_single_company,
            example_4_batch_entire_portfolio,
            example_5_custom_template,
            example_6_validate_model,
            example_7_missing_data_handling,
            example_8_performance_benchmark,
            example_9_merger_model,
            example_10_api_integration,
        ]
        
        if 1 <= example_num <= len(examples):
            examples[example_num - 1]()
        else:
            print(f"Invalid example number. Choose 1-{len(examples)}")
    else:
        # Show menu
        main()
