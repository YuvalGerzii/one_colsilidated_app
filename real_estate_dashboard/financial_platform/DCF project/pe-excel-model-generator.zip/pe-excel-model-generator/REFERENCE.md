# PE Excel Model Generator - Complete Reference

## Database Schema Overview

```sql
-- Core tables used for model generation
portfolio_companies (
    id UUID PRIMARY KEY,
    company_name VARCHAR(255),
    sector VARCHAR(100),
    investment_date DATE,
    status VARCHAR(50),
    equity_invested DECIMAL(15,2),
    debt_raised DECIMAL(15,2),
    entry_multiple DECIMAL(10,2),
    fund_id UUID
)

financial_metrics (
    id UUID PRIMARY KEY,
    company_id UUID REFERENCES portfolio_companies,
    period_date DATE,
    revenue DECIMAL(15,2),
    cogs DECIMAL(15,2),
    gross_profit DECIMAL(15,2),
    opex DECIMAL(15,2),
    ebitda DECIMAL(15,2),
    ebitda_margin DECIMAL(10,4),
    depreciation DECIMAL(15,2),
    ebit DECIMAL(15,2),
    interest_expense DECIMAL(15,2),
    tax_expense DECIMAL(15,2),
    net_income DECIMAL(15,2),
    total_assets DECIMAL(15,2),
    total_liabilities DECIMAL(15,2),
    shareholders_equity DECIMAL(15,2),
    cash DECIMAL(15,2),
    accounts_receivable DECIMAL(15,2),
    inventory DECIMAL(15,2),
    accounts_payable DECIMAL(15,2),
    operating_cash_flow DECIMAL(15,2),
    capex DECIMAL(15,2),
    free_cash_flow DECIMAL(15,2)
)

valuations (
    id UUID PRIMARY KEY,
    company_id UUID REFERENCES portfolio_companies,
    valuation_date DATE,
    wacc DECIMAL(10,4),
    cost_of_equity DECIMAL(10,4),
    cost_of_debt DECIMAL(10,4),
    terminal_growth_rate DECIMAL(10,4),
    unlevered_beta DECIMAL(10,4),
    risk_free_rate DECIMAL(10,4),
    market_risk_premium DECIMAL(10,4),
    tax_rate DECIMAL(10,4),
    debt_to_equity DECIMAL(10,4),
    exit_multiple DECIMAL(10,2),
    enterprise_value DECIMAL(15,2),
    equity_value DECIMAL(15,2)
)

company_kpis (
    id UUID PRIMARY KEY,
    company_id UUID REFERENCES portfolio_companies,
    period_date DATE,
    arr DECIMAL(15,2),
    mrr DECIMAL(15,2),
    churn_rate DECIMAL(10,4),
    customer_acquisition_cost DECIMAL(15,2),
    lifetime_value DECIMAL(15,2),
    gross_retention DECIMAL(10,4),
    net_retention DECIMAL(10,4),
    active_customers INTEGER,
    new_customers INTEGER,
    lost_customers INTEGER
)
```

---

## DCF Model - Complete Mapping

### Sheet: Cover Page

| Database Field | Excel Cell | Data Type | Format | Notes |
|---------------|------------|-----------|--------|-------|
| company.company_name | B2 | VARCHAR | Text | Company name |
| company.sector | B3 | VARCHAR | Text | Industry sector |
| company.investment_date | B4 | DATE | mm/dd/yyyy | Initial investment |
| company.fund_id → fund.name | B5 | VARCHAR | Text | Parent fund name |
| valuation.valuation_date | B6 | DATE | mm/dd/yyyy | Valuation as of date |
| financial_metrics[latest].revenue | C10 | DECIMAL | $#,##0 | Most recent revenue |
| financial_metrics[latest].ebitda | C11 | DECIMAL | $#,##0 | Most recent EBITDA |
| financial_metrics[latest].ebitda_margin | C12 | DECIMAL | 0.0% | EBITDA / Revenue |

### Sheet: DCF Analysis

| Database Field | Excel Cell | Data Type | Format | Notes |
|---------------|------------|-----------|--------|-------|
| financial_metrics[year-5].revenue | C8 | DECIMAL | $#,##0 | Historical year 1 |
| financial_metrics[year-4].revenue | D8 | DECIMAL | $#,##0 | Historical year 2 |
| financial_metrics[year-3].revenue | E8 | DECIMAL | $#,##0 | Historical year 3 |
| financial_metrics[year-2].revenue | F8 | DECIMAL | $#,##0 | Historical year 4 |
| financial_metrics[year-1].revenue | G8 | DECIMAL | $#,##0 | Historical year 5 (base) |
| valuation.terminal_growth_rate | C16 | DECIMAL | 0.00% | Perpetuity growth |
| valuation.tax_rate | C17 | DECIMAL | 0.00% | Corporate tax rate |

**Formula Cells (DO NOT OVERWRITE):**
- H8: `=G8*(1+H9)` - Forecast year 1 revenue
- I8: `=H8*(1+I9)` - Forecast year 2 revenue
- C20: `=NPV(WACC,H8:L8)+L8/(WACC-TermGrowth)` - Enterprise value
- C22: `=C20-NetDebt` - Equity value
- C23: `=C22/SharesOutstanding` - Price per share

### Sheet: Historical Financials

| Database Field | Excel Cell | Data Type | Format | Loop Pattern |
|---------------|------------|-----------|--------|--------------|
| financial_metrics[i].period_date | Row 5, Col C+i | DATE | yyyy | Year headers |
| financial_metrics[i].revenue | Row 8, Col C+i | DECIMAL | $#,##0 | Revenue row |
| financial_metrics[i].cogs | Row 9, Col C+i | DECIMAL | $#,##0 | COGS row |
| financial_metrics[i].gross_profit | Row 10, Col C+i | DECIMAL | $#,##0 | Gross profit |
| financial_metrics[i].opex | Row 12, Col C+i | DECIMAL | $#,##0 | Operating expenses |
| financial_metrics[i].ebitda | Row 15, Col C+i | DECIMAL | $#,##0 | EBITDA |
| financial_metrics[i].depreciation | Row 16, Col C+i | DECIMAL | $#,##0 | D&A |
| financial_metrics[i].ebit | Row 17, Col C+i | DECIMAL | $#,##0 | EBIT |
| financial_metrics[i].interest_expense | Row 18, Col C+i | DECIMAL | $#,##0 | Interest |
| financial_metrics[i].tax_expense | Row 19, Col C+i | DECIMAL | $#,##0 | Taxes |
| financial_metrics[i].net_income | Row 20, Col C+i | DECIMAL | $#,##0 | Net income |

### Sheet: WACC Calculation

| Database Field | Excel Cell | Data Type | Format | Notes |
|---------------|------------|-----------|--------|-------|
| valuation.risk_free_rate | C5 | DECIMAL | 0.00% | 10Y Treasury rate |
| valuation.market_risk_premium | C6 | DECIMAL | 0.00% | Equity risk premium |
| valuation.unlevered_beta | C8 | DECIMAL | 0.00 | Industry beta |
| valuation.debt_to_equity | C10 | DECIMAL | 0.00 | D/E ratio |
| valuation.cost_of_debt | C12 | DECIMAL | 0.00% | Pre-tax cost of debt |
| valuation.tax_rate | C13 | DECIMAL | 0.00% | Tax rate |

**Formula Cells:**
- C15: `=C5+C8*C6` - Cost of equity (CAPM)
- C16: `=C12*(1-C13)` - After-tax cost of debt
- C20: `=(C15*E/(E+D))+(C16*D/(E+D))` - WACC

### Sheet: Scenario Analysis

| Database Field | Excel Cell | Data Type | Format | Notes |
|---------------|------------|-----------|--------|-------|
| scenarios[base].revenue_growth | C10 | DECIMAL | 0.0% | Base case growth |
| scenarios[base].ebitda_margin | C11 | DECIMAL | 0.0% | Base case margin |
| scenarios[upside].revenue_growth | D10 | DECIMAL | 0.0% | Upside growth |
| scenarios[upside].ebitda_margin | D11 | DECIMAL | 0.0% | Upside margin |
| scenarios[downside].revenue_growth | E10 | DECIMAL | 0.0% | Downside growth |
| scenarios[downside].ebitda_margin | E11 | DECIMAL | 0.0% | Downside margin |

---

## LBO Model - Complete Mapping

### Sheet: Transaction Assumptions

| Database Field | Excel Cell | Data Type | Format | Notes |
|---------------|------------|-----------|--------|-------|
| company.company_name | B2 | VARCHAR | Text | Target company |
| company.investment_date | B3 | DATE | mm/dd/yyyy | Close date |
| financial_metrics[latest].revenue | C6 | DECIMAL | $#,##0 | LTM revenue |
| financial_metrics[latest].ebitda | C7 | DECIMAL | $#,##0 | LTM EBITDA |
| company.entry_multiple | C9 | DECIMAL | 0.0x | Purchase multiple |
| valuation.exit_multiple | C12 | DECIMAL | 0.0x | Exit multiple |
| transactions.purchase_price | C15 | DECIMAL | $#,##0 | Total consideration |

**Formula Cells:**
- C15: `=C7*C9` - Purchase price (EBITDA × Multiple)
- C16: `=C15+NetDebt+Fees` - Total uses

### Sheet: Sources & Uses

| Database Field | Excel Cell | Data Type | Format | Notes |
|---------------|------------|-----------|--------|-------|
| company.equity_invested | C10 | DECIMAL | $#,##0 | Sponsor equity |
| management_equity | C11 | DECIMAL | $#,##0 | Mgmt rollover |
| company.debt_raised | C15 | DECIMAL | $#,##0 | Senior debt |
| mezzanine_debt | C16 | DECIMAL | $#,##0 | Mezz financing |
| transactions.purchase_price | D8 | DECIMAL | $#,##0 | Purchase price (uses) |
| transaction_fees | D10 | DECIMAL | $#,##0 | Fees & expenses |
| refinance_debt | D12 | DECIMAL | $#,##0 | Repay existing debt |

**Formula Cells:**
- C20: `=SUM(C10:C17)` - Total sources
- D20: `=SUM(D8:D15)` - Total uses
- D22: `=C20-D20` - Balance check (should = 0)

### Sheet: Operating Model

| Database Field | Excel Cell | Data Type | Format | Notes |
|---------------|------------|-----------|--------|-------|
| financial_metrics[base_year].revenue | C8 | DECIMAL | $#,##0 | Year 0 revenue |
| revenue_growth[year1] | C9 | DECIMAL | 0.0% | Y1 growth assumption |
| financial_metrics[base_year].ebitda_margin | C12 | DECIMAL | 0.0% | Base EBITDA margin |
| margin_expansion[year1] | C13 | DECIMAL | 0.0% | Margin improvement |
| capex_percent_revenue | C18 | DECIMAL | 0.0% | CapEx as % revenue |

**Formula Cells:**
- D8: `=C8*(1+D9)` - Year 1 revenue
- D15: `=D8*D12` - Year 1 EBITDA
- D20: `=D15-D16-D18` - Unlevered FCF

### Sheet: Debt Schedule

| Database Field | Excel Cell | Data Type | Format | Notes |
|---------------|------------|-----------|--------|-------|
| senior_debt.principal | C8 | DECIMAL | $#,##0 | Opening balance |
| senior_debt.interest_rate | C9 | DECIMAL | 0.00% | Interest rate |
| senior_debt.amortization | C10 | DECIMAL | 0.0% | Mandatory paydown % |
| revolver.commitment | C15 | DECIMAL | $#,##0 | Revolver size |

**Formula Cells:**
- D12: `=C8*C9` - Interest expense
- D13: `=MIN(D20,C8*C10)` - Mandatory repayment
- D14: `=MAX(0,D20-D13)` - Optional paydown
- D8: `=C8-D13-D14` - Ending balance

### Sheet: Returns Analysis

| Database Field | Excel Cell | Data Type | Format | Notes |
|---------------|------------|-----------|--------|-------|
| company.equity_invested | C5 | DECIMAL | $#,##0 | Initial investment |
| forecast.exit_year | C8 | INTEGER | # | Years to exit |
| valuation.exit_multiple | C10 | DECIMAL | 0.0x | Exit EBITDA multiple |

**Formula Cells:**
- C15: `=ExitYearEBITDA*C10` - Enterprise value at exit
- C16: `=C15-NetDebt` - Equity value at exit
- C20: `=IRR(CashFlows)` - Gross IRR
- C21: `=C16/C5` - MOIC (Money-on-Money)
- C22: `=(C16/C5)^(1/C8)-1` - Annualized return

---

## Merger Model - Complete Mapping

### Sheet: Transaction Assumptions

| Database Field | Excel Cell | Data Type | Format | Notes |
|---------------|------------|-----------|--------|-------|
| acquirer.company_name | B2 | VARCHAR | Text | Acquiring company |
| target.company_name | B3 | VARCHAR | Text | Target company |
| transaction.announcement_date | B5 | DATE | mm/dd/yyyy | Deal announcement |
| transaction.expected_close | B6 | DATE | mm/dd/yyyy | Expected close |
| transaction.purchase_price | C10 | DECIMAL | $#,##0 | Total consideration |
| transaction.form_of_consideration | B12 | VARCHAR | Text | Cash/Stock/Mixed |
| acquirer.shares_outstanding | C15 | DECIMAL | #,##0 | Pre-deal shares |
| new_shares_issued | C16 | DECIMAL | #,##0 | Shares for transaction |

### Sheet: Purchase Price Allocation (PPA)

| Database Field | Excel Cell | Data Type | Format | Notes |
|---------------|------------|-----------|--------|-------|
| target.current_assets | C8 | DECIMAL | $#,##0 | Cash, AR, inventory |
| target.ppe | C10 | DECIMAL | $#,##0 | Property, plant, equipment |
| target.current_liabilities | C15 | DECIMAL | $#,##0 | AP, accruals |
| target.long_term_debt | C17 | DECIMAL | $#,##0 | Assumed debt |
| target.shareholders_equity | C20 | DECIMAL | $#,##0 | Book value |
| transaction.purchase_price | C25 | DECIMAL | $#,##0 | Purchase price |

**Formula Cells:**
- C30: `=C25-C20` - Total intangibles
- C31: `=C30*0.30` - Identifiable intangibles (estimate)
- C32: `=C30-C31` - Goodwill

### Sheet: Pro Forma Income Statement

| Database Field | Excel Cell | Data Type | Format | Notes |
|---------------|------------|-----------|--------|-------|
| acquirer.revenue[year1] | C8 | DECIMAL | $#,##0 | Acquirer standalone |
| target.revenue[year1] | D8 | DECIMAL | $#,##0 | Target standalone |
| synergies.revenue_synergies[year1] | E8 | DECIMAL | $#,##0 | Revenue synergies |
| acquirer.cogs[year1] | C10 | DECIMAL | $#,##0 | Acquirer COGS |
| target.cogs[year1] | D10 | DECIMAL | $#,##0 | Target COGS |
| synergies.cost_synergies[year1] | E10 | DECIMAL | ($#,##0) | Cost savings |

**Formula Cells:**
- F8: `=C8+D8+E8` - Pro forma revenue
- F10: `=C10+D10-E10` - Pro forma COGS (synergies reduce costs)
- F15: `=F8-F10-F12` - Pro forma EBITDA

### Sheet: Accretion/Dilution Analysis

| Database Field | Excel Cell | Data Type | Format | Notes |
|---------------|------------|-----------|--------|-------|
| acquirer.eps_standalone | C8 | DECIMAL | $0.00 | Acquirer EPS before deal |
| target.earnings | C10 | DECIMAL | $#,##0 | Target net income |
| synergies.total_synergies | C12 | DECIMAL | $#,##0 | After-tax synergies |
| transaction.interest_on_debt | C15 | DECIMAL | $#,##0 | Debt financing cost |
| acquirer.tax_rate | C17 | DECIMAL | 0.0% | Tax rate |
| acquirer.shares_outstanding | C20 | DECIMAL | #,##0 | Pre-deal shares |
| new_shares_issued | C21 | DECIMAL | #,##0 | New shares issued |

**Formula Cells:**
- C25: `=(AcquirerNI+TargetNI+Synergies-Interest)*(1-TaxRate)` - Pro forma NI
- C26: `=C20+C21` - Pro forma shares outstanding
- C28: `=C25/C26` - Pro forma EPS
- C30: `=(C28/C8)-1` - Accretion/(Dilution) %

### Sheet: Synergies

| Database Field | Excel Cell | Data Type | Format | Notes |
|---------------|------------|-----------|--------|-------|
| synergies.cost_synergies_year1 | C10 | DECIMAL | $#,##0 | Year 1 cost savings |
| synergies.cost_synergies_year2 | D10 | DECIMAL | $#,##0 | Year 2 cost savings |
| synergies.cost_synergies_year3 | E10 | DECIMAL | $#,##0 | Year 3 cost savings (full run-rate) |
| synergies.revenue_synergies_year1 | C15 | DECIMAL | $#,##0 | Year 1 revenue uplift |
| synergies.revenue_synergies_year2 | D15 | DECIMAL | $#,##0 | Year 2 revenue uplift |
| synergies.revenue_synergies_year3 | E15 | DECIMAL | $#,##0 | Year 3 revenue uplift |
| synergies.one_time_costs | C20 | DECIMAL | $#,##0 | Integration costs |

---

## DD Tracker - Complete Mapping

### Sheet: Overview Dashboard

| Database Field | Excel Cell | Data Type | Format | Notes |
|---------------|------------|-----------|--------|-------|
| company.company_name | B2 | VARCHAR | Text | Target company |
| dd_process.start_date | B5 | DATE | mm/dd/yyyy | DD kickoff |
| dd_process.expected_completion | B6 | DATE | mm/dd/yyyy | Target completion |
| dd_process.lead_associate | B8 | VARCHAR | Text | Process owner |

**Formula Cells:**
- C15: `=COUNTIF(AllItems,"Complete")` - Completed items
- C16: `=COUNTIF(AllItems,"In Progress")` - In progress
- C17: `=COUNTIF(AllItems,"Not Started")` - Not started
- C18: `=COUNTA(AllItems)` - Total items
- C20: `=C15/C18` - Completion %

### Sheet: Legal Due Diligence

| Database Field | Excel Cell | Data Type | Format | Loop Pattern |
|---------------|------------|-----------|--------|--------------|
| dd_items[category='Legal'][i].item_name | Row 5+i, Col B | VARCHAR | Text | Item description |
| dd_items[category='Legal'][i].status | Row 5+i, Col E | VARCHAR | Dropdown | Not Started/In Progress/Complete |
| dd_items[category='Legal'][i].assigned_to | Row 5+i, Col F | VARCHAR | Text | Person responsible |
| dd_items[category='Legal'][i].due_date | Row 5+i, Col G | DATE | mm/dd/yyyy | Target date |
| dd_items[category='Legal'][i].notes | Row 5+i, Col H | VARCHAR | Text | Comments |

Items include:
1. Corporate documents (articles, bylaws)
2. Material contracts review
3. Litigation and disputes
4. IP registration and protection
5. Regulatory compliance
... (20+ items total)

### Sheet: Financial Due Diligence

Similar structure to Legal DD, category='Financial':
1. Historical financial statements (3-5 years)
2. Quality of earnings analysis
3. Working capital analysis
4. Revenue recognition policies
5. Cost structure analysis
... (25+ items total)

### Sheet: Commercial Due Diligence

Similar structure, category='Commercial':
1. Market size and growth
2. Competitive positioning
3. Customer concentration
4. Customer satisfaction surveys
5. Pricing strategy analysis
... (20+ items total)

---

## QoE Analysis - Complete Mapping

### Sheet: EBITDA Adjustments

| Database Field | Excel Cell | Data Type | Format | Notes |
|---------------|------------|-----------|--------|-------|
| company.company_name | B2 | VARCHAR | Text | Company name |
| qoe_analysis.period_start | B5 | DATE | mm/dd/yyyy | Analysis period start |
| qoe_analysis.period_end | B6 | DATE | mm/dd/yyyy | Analysis period end |
| financial_metrics[latest].ebitda | C10 | DECIMAL | $#,##0 | Reported EBITDA |

**Adjustment Categories (each row is an adjustment):**

| Adjustment Type | Excel Cell | Data Type | Format | Notes |
|----------------|------------|-----------|--------|-------|
| qoe_adjustments[i].description | Row 15+i, Col B | VARCHAR | Text | Nature of adjustment |
| qoe_adjustments[i].amount | Row 15+i, Col C | DECIMAL | $#,##0 | Adjustment amount |
| qoe_adjustments[i].recurring | Row 15+i, Col D | BOOLEAN | Yes/No | One-time vs recurring |
| qoe_adjustments[i].category | Row 15+i, Col E | VARCHAR | Text | Category |

Common adjustment categories:
- Non-recurring expenses (restructuring, M&A costs)
- Stock-based compensation
- Above/below market rent
- Related party transactions
- Excess owner compensation
- Legal/settlement costs
- Change in accounting policies

**Formula Cells:**
- C50: `=C10+SUM(C15:C45)` - Adjusted EBITDA
- C52: `=SUMIF(D:D,"No",C:C)` - Total non-recurring adjustments
- C53: `=C50-C52` - Normalized run-rate EBITDA

### Sheet: Revenue Quality

| Database Field | Excel Cell | Data Type | Format | Notes |
|---------------|------------|-----------|--------|-------|
| revenue_analysis[i].customer_name | Row 10+i, Col B | VARCHAR | Text | Top 10 customers |
| revenue_analysis[i].revenue | Row 10+i, Col C | DECIMAL | $#,##0 | Annual revenue |
| revenue_analysis[i].revenue_percent | Row 10+i, Col D | DECIMAL | 0.0% | % of total |
| revenue_analysis[i].contract_type | Row 10+i, Col E | VARCHAR | Text | Recurring/One-time |
| revenue_analysis[i].contract_end_date | Row 10+i, Col F | DATE | mm/dd/yyyy | Contract expiry |

**Formula Cells:**
- D10: `=C10/TotalRevenue` - Customer concentration %
- C25: `=SUMIF(E:E,"Recurring",C:C)` - Recurring revenue
- C26: `=C25/TotalRevenue` - Recurring %

---

## Code Generation Patterns

### Pattern 1: Loading Historical Data

```python
def _load_historical_financials(self):
    """Load 5 years of historical data"""
    financials = self.db.query(FinancialMetric)\
        .filter(FinancialMetric.company_id == self.company_id)\
        .order_by(FinancialMetric.period_date.desc())\
        .limit(5)\
        .all()
    
    return sorted(financials, key=lambda x: x.period_date)
```

### Pattern 2: Populating Time-Series Data

```python
def _populate_historical_revenue(self, sheet, start_col='C', start_row=8):
    """Populate revenue row across multiple years"""
    for i, financial in enumerate(self.financials):
        col = chr(ord(start_col) + i)  # C, D, E, F, G
        cell = f'{col}{start_row}'
        
        sheet[cell].value = float(financial.revenue) if financial.revenue else 0
        apply_number_format(sheet[cell], 'currency')
        apply_input_style(sheet[cell])
```

### Pattern 3: Conditional Data Population

```python
def _populate_valuation_inputs(self):
    """Populate valuation inputs if available"""
    if not self.valuation:
        logger.warning(f"No valuation data for company {self.company_id}")
        return
    
    sheet = self.wb['WACC']
    
    # Only populate if data exists
    if self.valuation.wacc:
        sheet['C20'].value = float(self.valuation.wacc)
        apply_input_style(sheet['C20'])
        apply_number_format(sheet['C20'], 'percent_decimal')
```

### Pattern 4: Error Handling

```python
def generate(self, output_path: str):
    """Generate model with comprehensive error handling"""
    try:
        # Load template
        if not os.path.exists(self.template_path):
            raise FileNotFoundError(f"Template not found: {self.template_path}")
        
        self.wb = load_workbook(self.template_path)
        
        # Populate data
        self._populate_company_info()
        self._populate_financials()
        self._populate_valuation()
        
        # Save
        self.wb.save(output_path)
        logger.info(f"✓ Model generated: {output_path}")
        
    except Exception as e:
        logger.error(f"✗ Generation failed: {e}")
        raise
```

---

## Validation Rules

### Required Fields for Each Model

**DCF Model:**
- ✅ company.company_name
- ✅ financial_metrics (at least 1 year)
- ✅ valuation.wacc OR (risk_free_rate + market_risk_premium + unlevered_beta)
- ⚠️ Optional: terminal_growth_rate (defaults to 2.5%)

**LBO Model:**
- ✅ company.company_name
- ✅ company.equity_invested
- ✅ company.entry_multiple OR transaction.purchase_price
- ✅ financial_metrics.ebitda (base year)
- ⚠️ Optional: debt_raised, exit_multiple

**Merger Model:**
- ✅ acquirer.company_name
- ✅ target.company_name
- ✅ transaction.purchase_price
- ✅ acquirer.shares_outstanding
- ⚠️ Optional: synergies data

**DD Tracker:**
- ✅ company.company_name
- ⚠️ All other fields optional (can start empty)

**QoE Analysis:**
- ✅ company.company_name
- ✅ financial_metrics (at least 1 year)
- ⚠️ Optional: qoe_adjustments (can start with reported EBITDA)

---

## Performance Benchmarks

Based on testing with real data:

| Model Type | Typical Size | Generation Time | Database Queries |
|------------|-------------|----------------|------------------|
| DCF | 13 sheets, 5 MB | 8-12 seconds | 5-8 queries |
| LBO | 12 sheets, 4 MB | 6-10 seconds | 4-6 queries |
| Merger | 10 sheets, 3 MB | 10-15 seconds | 8-12 queries (2 companies) |
| DD Tracker | 8 sheets, 2 MB | 3-5 seconds | 2-3 queries |
| QoE | 6 sheets, 2 MB | 4-6 seconds | 3-5 queries |

**Optimization Tips:**
- Use `joinedload` to avoid N+1 queries
- Cache templates after first load
- Batch multiple model generations
- Use connection pooling for database
